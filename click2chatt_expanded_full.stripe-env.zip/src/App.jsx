import React from "react";
import { CheckCircle, Sparkles, PhoneCall, Mail, Bot } from "lucide-react";


const PRO_LINK = import.meta.env.VITE_STRIPE_LINK_PRO || "#";
const PRO_PLUS_LINK = import.meta.env.VITE_STRIPE_LINK_PRO_PLUS || "#";
const FOUNDING_LINK = import.meta.env.VITE_STRIPE_LINK_FOUNDING || "#";

export default function App() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-river grid place-items-center text-white font-bold">C2</div>
            <div className="text-xl md:text-2xl font-bold tracking-tight">Click2Chatt</div>
          </div>
          <span className="chip bg-panel border border-slate-200 ml-1">AI Reply Engine</span>
          <div className="ml-auto flex items-center gap-2">
            <button className="btn-outline rounded-xl" onClick={()=>window.scrollTo({top:99999, behavior:'smooth'})}>Contact</button>
            <button className="btn-primary rounded-xl" onClick={()=>window.open(PRO_LINK, "_blank")}>Start Pro</button>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-3xl md:text-5xl font-bold leading-tight">
              Never miss a customer again.<br/>AI replies for SMS, Instagram, Facebook & Email.
            </h1>
            <p className="mt-4 text-slate-600">
              Click2Chatt answers instantly, books appointments, and hands off to a human when needed.
            </p>
            <div className="mt-6 flex gap-3">
              <button className="btn-primary rounded-xl" onClick={()=>window.open(PRO_PLUS_LINK,"_blank")}>Get Pro+ (Best for Busy Shops)</button>
              <button className="btn-outline rounded-xl" onClick={()=>document.getElementById('pricing').scrollIntoView({behavior:'smooth'})}>See Pricing</button>
            </div>
            <div className="mt-4 chip bg-gold text-ink">Founding 50 promo available</div>
          </div>
          <div className="card p-6">
            <div className="flex items-center gap-2 text-river">
              <Bot /> <span className="font-semibold">How it works</span>
            </div>
            <ol className="mt-3 space-y-2 text-sm text-slate-700">
              <li><span className="font-semibold">1.</span> Connect your number & social inboxes.</li>
              <li><span className="font-semibold">2.</span> Pick tone & office hours.</li>
              <li><span className="font-semibold">3.</span> AI replies instantly, you get notified.</li>
              <li><span className="font-semibold">4.</span> Review transcripts anytime.</li>
            </ol>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="chip bg-panel border border-slate-200"><CheckCircle className="w-4 h-4 mr-1"/>SMS</div>
              <div className="chip bg-panel border border-slate-200"><CheckCircle className="w-4 h-4 mr-1"/>Instagram</div>
              <div className="chip bg-panel border border-slate-200"><CheckCircle className="w-4 h-4 mr-1"/>Facebook</div>
              <div className="chip bg-panel border border-slate-200"><CheckCircle className="w-4 h-4 mr-1"/>Email</div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: <Sparkles className="w-5 h-5" />, title: "Book More Customers", text: "Instant replies convert more chats into appointments." },
            { icon: <PhoneCall className="w-5 h-5" />, title: "Answer Calls & Texts", text: "Missed a call? Auto-text back and keep the lead." },
            { icon: <Mail className="w-5 h-5" />, title: "Email + DMs", text: "Centralize messages; AI drafts and you approve, or auto-send." },
          ].map((f, i)=> (
            <div key={i} className="card p-5">
              <div className="flex items-center gap-2 text-river">{f.icon}<span className="font-semibold">{f.title}</span></div>
              <p className="mt-2 text-sm text-slate-700">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="max-w-6xl mx_auto px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Simple pricing</h2>
        <p className="text-slate-600 mt-1">Founding 50 can lock in discounts today.</p>
        <div className="grid md:grid-cols-3 gap-6 mt-6">
          <div className="card p-6">
            <div className="chip bg-gold text-ink mb-2">Founding</div>
            <div className="text-3xl font-bold">$19<span className="text-base font-medium text-slate-500">/mo</span></div>
            <ul className="mt-4 text-sm text-slate-700 space-y-2">
              <li>AI replies on 1 channel</li>
              <li>Office hours + human handoff</li>
              <li>Founding badge on profile</li>
            </ul>
            <button className="btn-primary rounded-xl mt-6 w-full" onClick={()=>window.open(FOUNDING_LINK,"_blank")}>Claim Founding</button>
          </div>
          <div className="card p-6 border-2 border-river">
            <div className="chip bg-panel border border-slate-200 mb-2">Pro</div>
            <div className="text-3xl font-bold">$49<span className="text-base font-medium text-slate-500">/mo</span></div>
            <ul className="mt-4 text-sm text-slate-700 space-y-2">
              <li>AI replies on 2 channels</li>
              <li>Auto-respond to missed calls</li>
              <li>Basic analytics</li>
            </ul>
            <button className="btn-primary rounded-xl mt-6 w-full" onClick={()=>window.open(PRO_LINK,"_blank")}>Start Pro</button>
          </div>
          <div className="card p-6">
            <div className="chip bg-panel border border-slate-200 mb-2">Pro+</div>
            <div className="text-3xl font-bold">$99<span className="text-base font-medium text-slate-500">/mo</span></div>
            <ul className="mt-4 text-sm text-slate-700 space-y-2">
              <li>AI replies on 4 channels</li>
              <li>Priority support</li>
              <li>Team seats</li>
            </ul>
            <button className="btn-outline rounded-xl mt-6 w-full" onClick={()=>window.open(PRO_PLUS_LINK,"_blank")}>Start Pro+</button>
          </div>
        </div>
      </section>

      <footer className="border-t mt-10">
        <div className="max-w-6xl mx-auto p-6 text-sm text-slate-500 flex flex-wrap items-center gap-3">
          <div>© {new Date().getFullYear()} Click2Chatt • Built for Chattanooga</div>
          <div className="ml-auto flex items-center gap-3">
            <a className="text-river" href="mailto:hello@click2chatt.com">hello@click2chatt.com</a>
          </div>
        </div>
      </footer>
    </div>
  );
}