/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        river: "#1363DF",
        gold: "#FDBA21",
        ink: "#0F172A",
        paper: "#FFFFFF",
        panel: "#F8FAFC",
      },
      boxShadow: {
        card: "0 4px 24px -6px rgba(15, 23, 42, 0.12)",
        soft: "0 6px 30px -8px rgba(15, 23, 42, 0.18)",
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.25rem",
      },
    },
  },
  plugins: [],
}
